using UnityEngine;

public class NPC
{
    
}
