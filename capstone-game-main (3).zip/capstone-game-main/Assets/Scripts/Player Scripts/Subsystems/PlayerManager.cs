using UnityEngine;

public abstract class PlayerManager
{
    protected Player player;
}