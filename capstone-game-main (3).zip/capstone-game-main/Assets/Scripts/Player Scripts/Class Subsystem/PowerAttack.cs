using UnityEngine;

public class PowerAttack : Power
{
    public Attack powerAttack;

    public override void Activate()
    {
        //empty
    }
    public override void Deactivate()
    {
        //empty
    }
}