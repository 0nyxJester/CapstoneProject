/*
using UnityEngine;
using System.Collections;
public class Wallet
{
    public static int balance;

    public bool Updategold(int payment)
        // Updates total amount of gold in wallet. For subtracting gold, payment will be negative 
        balance+=payment;
        // Checks if payment will cause wallet to become negative
        if (temp < 0)
        {
        // TODO: Print out a message that says you cannot afford this
        balance-=payment; // Rolls back transaction
        return false;
        }
        else
        {
        return true;
        }
    }
*/