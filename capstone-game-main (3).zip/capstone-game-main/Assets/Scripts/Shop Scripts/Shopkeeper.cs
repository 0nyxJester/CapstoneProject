using UnityEngine;
public class Shopkeeper
{
    public string ShopkeeperName;
    public int[,] ShopInventory;
    //TODO: add scripts that manage the array
    public void Buyitem(){
    
    //Runs payment
    }
}